package com.example.springboot;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ClothingController {
	
	@Autowired
	ClothingRepository repository;
	
	private final ArrayList<Clothing> clothings;

	public ClothingController() {
		clothings = new ArrayList<Clothing>();
		clothings.add(new Clothing(1L,"Torso Covering",150.50,"Shirt"));
		clothings.add(new Clothing(2L,"Denim Pantaloons", 200.50, "Pant"));
	}
	
	
	@GetMapping("/clothings")
	List<Clothing> all() {
		return clothings;
	}

	

	
	@GetMapping("/clothings/{id}")
	Clothing getClothing(@PathVariable Long id) {
	    return repository.findById(id).orElseThrow(() -> new ClothingNotFoundException(id));
	    
	}
	

}
