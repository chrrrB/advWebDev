angular.module('my-app', [])
  .controller('ClothingController', function($scope,$http) {
	$scope.message = "Clothes you've seen before";

	var onError = function(reason) {
		$scope.error = "Something got screwed up !!";
	};
	
	var onclothinglistcall = function(response) {
		$scope.clothings = response.data;
		console.log(response.data);
		console.log(response.status);
		console.log($scope.foods[0].protein)
	};
	
	$http.get("http://localhost:8081/clothings") //
		.then(onclothinglistcall,onError);
		
	
  });