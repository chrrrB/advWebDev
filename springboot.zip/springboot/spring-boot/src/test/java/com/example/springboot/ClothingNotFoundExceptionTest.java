package com.example.springboot;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ClothingNotFoundExceptionTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
