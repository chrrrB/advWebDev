package com.example.springboot;

import java.util.ArrayList;

public class Clothings {
	private ArrayList<Clothing> clothings;

	public Clothings() {
		clothings = new ArrayList<Clothing>();
		clothings.add(new Clothing(1L,"Brand Chicken",150.50,"Shirt"));
		clothings.add(new Clothing(2L,"Other brand chicken", 200.50, "Pant"));
	}
	
	public ArrayList<Clothing> getClothings() {
		return clothings;
	}
	public void setClothings(ArrayList<Clothing> clothings) {
		this.clothings = clothings;
	}

}
