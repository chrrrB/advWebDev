package com.example.springboot;

public class ClothingNotFoundException extends RuntimeException {

	public ClothingNotFoundException(Long id) {
		super("Can not find Food with id " + id);
	}

}
