package com.example.springboot;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CLOTHING")
public class Clothing {
	// Id is necessary for each table to be identified as unique identifier
	@Id
	@Column(name="CLOTHINGID")
	private Long clothingId;
	@Column(name="CLOTHINGNAME")
	private String clothingName;
	@Column(name="PRICE")
	private Double price;
	@Column(name="TYPE")
	private String type;
	public Clothing() {
		// TODO Auto-generated constructor stub
	}
	public Clothing(Long i, String n, Double a, String b) {
		clothingId = i;
		clothingName = n;
		price = a;
		type = b;
	}
	public Long getClothingId() {
		return clothingId;
	}
	public void setClothingId(Long clothingId) {
		this.clothingId = clothingId;
	}

	public String getClothingName() {
		return clothingName;
	}
	public void setClothingName(String clothingName) {
		this.clothingName = clothingName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	public String getType() {
		return type;
	}
	public void setPrice(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "Clothing{" + "id=" + this.clothingId + ", name='" +
				this.clothingName + "', price='" + this.price + ", type='" + this.type + "'}";
	}
	

}
